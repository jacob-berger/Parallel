Name: Jacob Berger
Description: Unzip jBergerCSCD467HW3.zip.
To Compile: cd into folder jBergerCSCD467HW3,
	javac *.java
To Run: java ParallelSearchCoarse fileName pattern
