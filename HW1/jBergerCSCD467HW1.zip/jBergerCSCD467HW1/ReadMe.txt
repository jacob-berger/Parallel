Name: Jacob Berger
Description: Unzip jBergerCSCD467HW1.zip.
To Compile: cd into folder jBergerCSCD467HW1,
	javac *.java
To Run: java HW1
