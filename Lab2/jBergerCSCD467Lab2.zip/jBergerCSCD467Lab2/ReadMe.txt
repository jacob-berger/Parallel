Name: Jacob Berger
Description: Unzip jBergerCSCD467Lab2.zip.
To Compile: cd into folder jBergerCSCD467Lab2,
	javac *.java
To Run: java Lab2
