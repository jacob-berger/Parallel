Name: Jacob Berger
Description: Unzip jBergerCSCD467Lab1.zip.
To Compile: cd into folder jBergerCSCD467Lab1,
	javac *.java
To Run: java Display
