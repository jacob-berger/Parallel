Name: Jacob Berger
Description: Unzip jBergerCSCD467HW2.zip.
To Compile: cd into folder jBergerCSCD467HW2,
	javac *.java
To Run: java MyPrimeTest numThreads low high
