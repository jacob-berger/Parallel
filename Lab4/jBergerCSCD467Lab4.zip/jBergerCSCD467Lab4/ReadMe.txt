Name: Jacob Berger
Description: Unzip jBergerCSCD467Lab4.zip.
To Compile: cd into folder jBergerCSCD467Lab4,
	javac *.java
To Run: java Alternating

